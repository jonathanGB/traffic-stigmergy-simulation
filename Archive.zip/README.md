# Traffic Stigmergy Simulation

### By Jonathan Guillotte-Blouin, Elena Wu-Yan, and Mark York

This was done as part of a research project for CS 289 (Biologically-Inspired Multi-Agent Systems) at Harvard.